// Copyright (c) 2026 Insta360. All rights reserved.
// INS_Reader · 新浪文章页适配器
// 职责：为新浪新闻文章页提供稳定的正文根节点、标题和降噪选择器。
// 只读查询真实页面，删除操作仍由 noise-filter.js 作用于 body 克隆体。

window.INS_Reader = window.INS_Reader || {};

(function () {
  const SINA_HOSTS = ['sina.com.cn', 'sina.cn'];

  function isSinaPage() {
    return SINA_HOSTS.some(
      (host) => location.hostname === host || location.hostname.endsWith(`.${host}`)
    );
  }

  function findArticleRootIn(root) {
    if (!isSinaPage() || !root || !root.querySelector) return null;
    return root.querySelector('#article, .article-content-left .article');
  }

  function findArticleRoot() {
    return findArticleRootIn(document);
  }

  function getNoiseSelectors() {
    if (!isSinaPage()) return {};
    return {
      ads: ['.sinaads', '.article-content-left > .ad', '.right-side-ad'],
      // 右栏整体包含阅读排行榜、评论排行榜、广告和视频推荐；按容器处理，避免重复计数。
      sidebar: ['.article-content-right', '.page-right-bar'],
      // 正文评论区，不包含右栏的评论排行榜（#read-comment）。
      comments: ['#bottom_sina_comment', '.blk-comment'],
      // 顶部横幅、站点导航、二维码和广告浮层。不把 .modal-content 算进来，
      // 以免误删包着正文的壳；原页 display:none 的蒙层由阅读层拷贝隐藏态处理。
      banners: [
        '.top-banner',
        '#sina-header',
        '.sina-header',
        '.nav-others',
        '#article-bottom',
        '.sinaad-toolkit-box',
        '.qrcode-modal',
        '[class*="qrcode"]',
        '[id*="qrcode"]',
        '[class*="qr-code"]',
        '[class*="ewm"]',
        '.modal-overlay',
      ],
      marketing: ['.modal-content', '[id*="login"]', '[class*="login"]'],
      // 与通用 video/iframe 规则合并：正文播放器、右栏视频卡，以及正文下方
      // 动态插入的图示/广告墙（赛博对话等栏目卡、带「广告」标的图片网格）。
      // 特别声明在 #article 内，不会被「#article 后面的兄弟」选中。
      blockAllVideos: [
        '[class*="article-video"]',
        '[data-video]',
        '[data-video-id]',
        '.news-video-miaopai',
        '.img-video-box',
        '#article-bottom',
        '.article-bottom',
        '#wxFollow',
        '#timeline_pc_tmpl',
        '#card_weibo_topic',
        '#sina_keyword_ad_area2',
        '.sina_keyword_ad_area',
        '[class*="sinaads"]',
        '.article-content-left > #article ~ *:not(#bottom_sina_comment):not(.blk-comment)',
      ],
    };
  }

  window.INS_Reader.siteAdapters = {
    isSinaPage,
    findArticleRoot,
    findArticleRootIn,
    getNoiseSelectors,
  };
})();
